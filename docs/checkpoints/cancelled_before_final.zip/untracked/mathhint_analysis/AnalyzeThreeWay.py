"""소단원 군집·회귀 벡터·세 조건 Gemini 실험을 표와 흑백 보고서로 정리한다.

상단 설정을 바꾸고 실행한다. 실제 해설 벡터 조건은 테스트 정답 정보를 제공한
진단 실험으로, 예측 벡터를 사용하는 일반 평가와 구분한다.
"""

from __future__ import annotations

from collections import Counter
import base64
import csv
import hashlib
import html
import json
import os
from pathlib import Path

from .AnalyzeExperiment import answer_metrics, exact_mcnemar, usage_summary, wilson_interval
from mathhint_solver.AnswerEvaluation import evaluate_answer


ROOT = Path(__file__).resolve().parents[1]
RUN_ROOT = ROOT / "outputs/subunit_threeway"
OUTPUT = RUN_ROOT / "report"
METHODS = ("baseline", "oracle_hint", "regression_hint")
NAMES = {"baseline": "문제만", "oracle_hint": "실제 해설 정수 벡터", "regression_hint": "예측 해설 정수 벡터"}
TOKENS = ("prompt_token_count", "candidates_token_count", "thoughts_token_count", "total_token_count")
TOKEN_NAMES = ("입력", "출력", "추론", "전체")
CONFLICTS = ROOT / "results/model_comparison_2026-11-07/03_Gemini비교/원본정답표_오류근거.json"


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def correct(row):
    value = row.get("evaluation", {}).get("correct") if row and row.get("status") == "success" else None
    return value if type(value) is bool else None


def paired_scores(latest, ids, left, right):
    pairs = [(i, correct(latest.get((i, left))), correct(latest.get((i, right)))) for i in ids]
    pairs = [(i, a, b) for i, a, b in pairs if a is not None and b is not None]
    cells = Counter("both_correct" if a and b else "left_only" if a else "right_only" if b else "both_incorrect"
                    for _, a, b in pairs)
    n = len(pairs)
    a, b = sum(x for _, x, _ in pairs), sum(y for _, _, y in pairs)
    return {"left": left, "right": right, "graded_pairs": n, "excluded_pairs": len(ids) - n,
            **{key: cells[key] for key in ("both_correct", "left_only", "right_only", "both_incorrect")},
            "left_correct": a, "right_correct": b, "left_accuracy": a / n if n else None,
            "right_accuracy": b / n if n else None,
            "difference_right_minus_left": (b - a) / n if n else None,
            "left_wilson95": wilson_interval(a, n), "right_wilson95": wilson_interval(b, n),
            "exact_mcnemar_p": exact_mcnemar(cells["left_only"], cells["right_only"]),
            "outcomes": [{"id": i, "left_correct": x, "right_correct": y} for i, x, y in pairs]}


def supplemental_scores(latest, ids, conflicts_path):
    """원본 정답표 점수는 유지하고, 근거가 있는 충돌 문항만 별도로 채점한다."""
    reviewed = dict(latest)
    conflicts = read_json(conflicts_path).get("records", []) if conflicts_path.exists() else []
    conflicts = [c for c in conflicts if c["id"] in ids]
    changes = []
    for conflict in conflicts:
        for method in METHODS:
            key = conflict["id"], method
            if key not in latest:
                continue
            row = latest[key]
            if row["reference_answer_text"] != conflict["original_answer"]:
                raise ValueError("정답표 충돌 근거와 원본 답이 다릅니다: " + conflict["id"])
            source = row.get("reference", {}).get("source", {}).get("source_sha256")
            if conflict.get("source_sha256") and source != conflict["source_sha256"]:
                raise ValueError("정답표 충돌 근거와 원본 파일 해시가 다릅니다: " + conflict["id"])
            evaluation = (evaluate_answer(row["output_text"], conflict["mathematically_supported_answer"], row["problem_text"])
                          if row.get("status") == "success" else row.get("evaluation", {}))
            reviewed[key] = {**row, "evaluation": evaluation}
            changes.append({"id": conflict["id"], "method": method, "original": row.get("evaluation"),
                            "supplemental": evaluation})
    return reviewed, {"conflicts": conflicts, "changes": changes,
                      "evidence_sha256": file_hash(conflicts_path) if conflicts_path.exists() else None,
                      "label": "근거를 둔 AI 보조 수학 검토 점수; 사람의 인증 판정과 구분",
                      "raw_data_modified": False}


def method_scores(latest, ids):
    result = {}
    for method in METHODS:
        rows = [latest[i, method] for i in ids if (i, method) in latest]
        result[method] = {**answer_metrics(rows, len(ids)), "usage": usage_summary(rows),
                          "new_api_usage": usage_summary([r for r in rows if r.get("response_origin") != "reused_control"]),
                          "reused_controls": sum(r.get("response_origin") == "reused_control" for r in rows),
                          "statuses": dict(Counter(r.get("status") for r in rows)),
                          "uses_actual_test_reference_vector": method == "oracle_hint"}
    return result


def paired_usage(latest, ids, left, right):
    result = {}
    for field in TOKENS:
        values = []
        for i in ids:
            a, b = latest.get((i, left)), latest.get((i, right))
            if not a or not b or a.get("status") != "success" or b.get("status") != "success":
                continue
            x, y = a.get("usage", {}).get(field), b.get("usage", {}).get(field)
            if type(x) in (int, float) and type(y) in (int, float):
                values.append((x, y))
        x, y = sum(a for a, _ in values), sum(b for _, b in values)
        result[field] = {"paired_responses": len(values), "left_sum": x if values else None,
                         "right_sum": y if values else None,
                         "mean_difference_right_minus_left": (y - x) / len(values) if values else None,
                         "relative_total_difference": (y - x) / x if values and x else None}
    return result


def analyze(run_root, conflicts_path=None):
    run_root = Path(run_root)
    folder = run_root / "generation"
    manifest = read_json(folder / "config.json")
    config = manifest["config"]
    ids = config["test_ids"]
    latest = {}
    path = folder / "responses.jsonl"
    for line in path.read_text().splitlines() if path.exists() else []:
        row = json.loads(line)
        if row.get("config_id") != manifest["config_id"]:
            raise ValueError("서로 다른 실험 설정의 응답이 섞였습니다.")
        if row["id"] not in ids or row["method"] not in METHODS:
            raise ValueError("예상하지 않은 문항 ID 또는 생성 조건입니다.")
        latest[row["id"], row["method"]] = row
    evidence = Path(conflicts_path) if conflicts_path else run_root / "audit/audited_answer_conflicts.json"
    if not evidence.exists() and conflicts_path is None:
        evidence = CONFLICTS
    reviewed, adjudication = supplemental_scores(latest, ids, evidence)
    comparisons = [("baseline", "oracle_hint"), ("baseline", "regression_hint"), ("oracle_hint", "regression_hint")]
    expected = len(ids) * len(METHODS)
    result = {"config_id": manifest["config_id"], "settings": config, "test_ids": ids,
              "expected_questions": len(ids), "expected_conditions": expected, "recorded_conditions": len(latest),
              "successful_conditions": sum(r.get("status") == "success" for r in latest.values()),
              "complete": len(latest) == expected and all(r.get("status") == "success" for r in latest.values()),
              "source_key": method_scores(latest, ids),
              "supplemental_key": {**adjudication, "methods": method_scores(reviewed, ids)},
              "paired_source": {f"{a}_vs_{b}": paired_scores(latest, ids, a, b) for a, b in comparisons},
              "paired_supplemental": {f"{a}_vs_{b}": paired_scores(reviewed, ids, a, b) for a, b in comparisons},
              "paired_tokens": {f"{a}_vs_{b}": paired_usage(latest, ids, a, b) for a, b in comparisons},
              "source_hashes": {"config": file_hash(folder / "config.json"),
                                "responses": file_hash(path) if path.exists() else None},
              "interpretation": ["실제 해설 벡터는 테스트 정답 정보를 제공하는 진단 조건이다. 일반 예측 성능으로 해석하지 않는다.",
                                 "원시 빈도는 정수이며 회귀 실수 예측은 음수→0, 0.5 이상 올림으로 정수화한다.",
                                 "두 벡터 조건은 같은 어휘 순서의 전체 정수 벡터를 전달하며 0 좌표만 생략한다.",
                                 "원본 정답표 점수와 근거를 둔 보조 점수를 구분하고 원본 응답을 수정하지 않는다.",
                                 "방식별 1회 생성한 결과이며 대응 비교는 같은 판독 가능 문항만 사용한다.",
                                 "토큰은 성공 응답 사용량을 비교한다. 실패·추론 사용량 미제공은 0으로 추정하지 않는다."]}
    for key, relative in [("regression", "regression/vector_comparison_summary.json"),
                          ("clustering", "clustering/clustering_metrics.json")]:
        target = run_root / relative
        result[key] = read_json(target) if target.exists() else None
        result["source_hashes"][key] = file_hash(target) if target.exists() else None
    return result, latest, reviewed


def number(value, digits=2):
    return "미제공" if value is None else f"{value:,.{digits}f}"


def percent(value):
    return "미제공" if value is None else f"{value:.2%}"


def markdown_report(result):
    n = result["expected_questions"]
    state = "전체 응답 확보" if result["complete"] else "진행 중 부분 결과"
    config = result["settings"]
    lines = ["# 소단원·회귀·세 조건 답변 비교", "", f"**{state}: 성공 응답 {result['successful_conditions']}/{result['expected_conditions']}개.**",
             f"학습 {len(config['train_ids'])}개·테스트 {n}개 고정. 모델 {config['model']} / {config['thinking_level']} / temperature {config['temperature']}.", "",
             "## 1. 실제 소단원 수의 군집화", ""]
    cluster = result["clustering"]
    if cluster:
        c, m = cluster["config"], cluster["metrics"]["test"]["subunit"]
        lines += [f"군집 수 **{c['n_clusters']}개**. 학습 소단원 {c['train_subunit_count']}개·테스트 소단원 {c['test_subunit_count']}개.",
                  "소단원은 교육과정·단원·소단원을 연결해 구분한다. 중심과 다수 라벨은 학습에서만 정했다.", "",
                  "|테스트 소단원 평가|값|", "|---|---:|",
                  f"|ARI|{number(m['adjusted_rand_index'], 4)}|",
                  f"|NMI|{number(m['normalized_mutual_information'], 4)}|",
                  f"|학습 군집 다수 라벨의 테스트 정확도|{percent(m['accuracy_using_train_cluster_majority'])}|", "",
                  "[군집별 문항 파일](../clustering/clusters/) · [군집 요약 CSV](../clustering/cluster_summary.csv) · [문항별 군집 CSV](../clustering/cluster_assignments.csv)",
                  "![소단원과 군집 대응](../clustering/subunit_cluster_heatmap.png)", ""]
    else:
        lines += ["군집 결과가 아직 저장되지 않았다.", ""]
    lines += ["## 2. 회귀 예측과 실제 정답·해설 벡터", "",
              "원래 실수 예측, 음수를 0으로 바꾼 값, 정수 반올림 값을 구분한다. 학습 자체는 실수 오차로 수행한다.",
              "0인 좌표가 많으므로 전체 좌표 일치율만 보지 않고 실제 또는 예측이 양수인 좌표의 일치율도 확인한다.", ""]
    regression = result["regression"]
    if regression:
        metrics = regression.get("metrics", regression)
        lines += ["|벡터|MSE ↓|MAE ↓|코사인 ↑|전체 좌표 일치율|양수 합집합 좌표 일치율|", "|---|---:|---:|---:|---:|---:|"]
        for key, name in [("raw", "실수 예측"), ("clipped", "음수→0"), ("rounded", "정수 반올림"), ("training_mean", "학습 평균 기준선")]:
            row = metrics.get(key)
            if row:
                lines.append(f"|{name}|{number(row['mse'],4)}|{number(row['mae'],4)}|{number(row['mean_cosine_similarity'],4)}|{percent(row.get('coordinate_exact_rate_including_zeros'))}|{percent(row.get('active_coordinate_exact_rate'))}|")
        lines += ["", "[문항별 벡터 지표](../regression/vector_metrics.csv) · [모든 토큰의 실제·예측 빈도 비교](../regression/token_comparison.csv) · [문항별 차이](../regression/questions/)", ""]
    else:
        lines += ["회귀 벡터 비교 결과가 아직 저장되지 않았다.", ""]
    lines += ["## 3. 같은 테스트 문항의 Gemini 세 조건 비교", "",
              "**실제 해설 벡터 조건은 테스트 정답 정보를 제공한 실험이다.** 회귀 예측만 사용하는 조건과 같은 의미의 일반화 성능으로 해석하지 않는다.",
              "두 벡터 조건 모두 같은 전체 정수 벡터 표현과 동일한 안내 문구를 사용한다. 상위 토큰 일부로 자르지 않는다.", "",
              "|조건|원본 정답표 정답/판독|원본 정답률|수학 검토 보조 정답/판독|보조 정답률|미판독·누락|", "|---|---:|---:|---:|---:|---:|"]
    for method in METHODS:
        a, b = result["source_key"][method], result["supplemental_key"]["methods"][method]
        lines.append(f"|{NAMES[method]}|{a['correct']}/{a['graded_responses']}|{percent(a['accuracy_on_graded'])}|{b['correct']}/{b['graded_responses']}|{percent(b['accuracy_on_graded'])}|{a['ungraded_or_missing']}|")
    lines += ["", "정답표 충돌은 근거가 있는 문항만 보조 채점한다. 원본 답과 채점은 그대로 보존하며 보조 점수는 사람의 인증 정답표가 아니다.", "",
              "|성공 응답 평균 토큰|문제만|실제 해설 벡터|예측 해설 벡터|", "|---|---:|---:|---:|"]
    for field, label in zip(TOKENS, TOKEN_NAMES):
        values = [number(result["source_key"][method]["usage"][field]["successful_response_mean"], 1) for method in METHODS]
        lines.append("|" + "|".join([label, *values]) + "|")
    lines += ["", "평균은 각 조건의 성공 응답 사용량이다. 대응 토큰 차이와 실패·재시도 사용량은 JSON에서 따로 확인한다. 재사용 대조군 사용량은 비교에 포함하고 새 호출 사용량과 구분했다.", "",
              "|원본 정답표 대응 비교|같이 판독된 문항|왼쪽만 정답|오른쪽만 정답|정답률 차이(오른쪽−왼쪽)|McNemar p|", "|---|---:|---:|---:|---:|---:|"]
    for p in result["paired_source"].values():
        lines.append(f"|{NAMES[p['left']]} → {NAMES[p['right']]}|{p['graded_pairs']}|{p['left_only']}|{p['right_only']}|{percent(p['difference_right_minus_left'])}|{number(p['exact_mcnemar_p'],4)}|")
    lines += ["", "[문항별 세 풀이 비교 화면](../generation/report.html) · [80문항 요약 CSV](80문항_세조건_비교.csv) · [입력·출력 전문 CSV](문항별_입출력_전체.csv)", "",
              "## 해석 범위", ""] + ["- " + note for note in result["interpretation"]]
    lines += ["- 새로운 응답의 풀이 타당성·교과 범위는 이 보고서에서 자동 확정하지 않는다."]
    return "\n".join(lines) + "\n"


def export_question_tables(output, ids, latest, reviewed):
    fields = ["id", "original_answer", "supplemental_answer"]
    fields += [f"{method}_{key}" for method in METHODS for key in ("source_correct", "supplemental_correct", "final_answer", "input_tokens", "output_tokens", "total_tokens")]
    with (output / "80문항_세조건_비교.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for i in ids:
            first = next((latest[i, m] for m in METHODS if (i, m) in latest), {})
            original = first.get("reference_answer_text")
            row = {"id": i, "original_answer": original, "supplemental_answer": original}
            for method in METHODS:
                raw, fixed = latest.get((i, method), {}), reviewed.get((i, method), {})
                evaluation = fixed.get("evaluation", {})
                if evaluation.get("reference_answer"):
                    row["supplemental_answer"] = evaluation["reference_answer"]
                row.update({f"{method}_source_correct": correct(raw), f"{method}_supplemental_correct": correct(fixed),
                            f"{method}_final_answer": raw.get("evaluation", {}).get("predicted_answer")})
                for name, field in [("input_tokens", "prompt_token_count"), ("output_tokens", "candidates_token_count"), ("total_tokens", "total_token_count")]:
                    row[f"{method}_{name}"] = raw.get("usage", {}).get(field)
            writer.writerow(row)
    fields = ["id", "method", "status", "reference_answer", "source_correct", "supplemental_correct", "input_tokens", "output_tokens", "total_tokens", "input_text", "output_text", "reference_solution"]
    with (output / "문항별_입출력_전체.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for i in ids:
            for method in METHODS:
                r = latest.get((i, method))
                if not r:
                    continue
                row = {key: r.get(key) for key in ("id", "method", "status", "input_text", "output_text", "reference_solution")}
                row.update(reference_answer=r.get("reference_answer_text"), source_correct=correct(r), supplemental_correct=correct(reviewed.get((i, method))))
                row.update(input_tokens=r.get("usage", {}).get("prompt_token_count"), output_tokens=r.get("usage", {}).get("candidates_token_count"), total_tokens=r.get("usage", {}).get("total_token_count"))
                writer.writerow(row)


def render_figures(result, run_root, output):
    os.environ.setdefault("MPLCONFIGDIR", str(output / ".matplotlib_cache"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from matplotlib.backends.backend_pdf import PdfPages
    font = Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=str(font)).get_name()
    plt.rcParams.update({"axes.unicode_minus": False, "axes.spines.top": False, "axes.spines.right": False})
    figures = []
    fig, axes = plt.subplots(1, 2, figsize=(11.7, 4.2))
    for axis, key, title in zip(axes, ("source_key", "supplemental_key"), ("원본 정답표", "수학 검토 보조 점수")):
        rows = result[key] if key == "source_key" else result[key]["methods"]
        values = [rows[m]["accuracy_on_graded"] for m in METHODS]
        bars = axis.bar(range(3), [100 * v if v is not None else 0 for v in values], color=["white", "#aaa", "#444"], edgecolor="black")
        axis.set_xticks(range(3), ["문제만", "실제 벡터", "예측 벡터"])
        axis.set_ylim(0, 112);axis.set_ylabel("판독 가능한 응답의 정답률 (%)");axis.set_title(title)
        for bar, v, m in zip(bars, values, METHODS):
            text = "미판독" if v is None else f"{v:.1%}\n{rows[m]['correct']}/{rows[m]['graded_responses']}"
            axis.text(bar.get_x()+bar.get_width()/2, bar.get_height()+2, text, ha="center", fontsize=9)
    fig.suptitle("실제 벡터 조건은 테스트 정답 정보를 제공한 진단 조건")
    fig.tight_layout();figures.append(("세조건_정답률", fig))
    fig, axes = plt.subplots(1, 3, figsize=(11.7, 4.2))
    for axis, field, label in zip(axes, ("prompt_token_count", "candidates_token_count", "total_token_count"), ("입력", "출력", "전체")):
        values = [result["source_key"][m]["usage"][field]["successful_response_mean"] for m in METHODS]
        bars=axis.bar(range(3), [v if v is not None else 0 for v in values], color=["white", "#aaa", "#444"], edgecolor="black")
        axis.set_xticks(range(3), ["문제만", "실제 벡터", "예측 벡터"]);axis.set_title(label+" 토큰");axis.set_ylabel("성공 응답당 평균")
        for bar, v in zip(bars, values):axis.text(bar.get_x()+bar.get_width()/2,bar.get_height(),"미제공" if v is None else f"{v:.1f}",ha="center",va="bottom",fontsize=9)
    fig.tight_layout();figures.append(("세조건_토큰사용량", fig))
    paths=[]
    with PdfPages(output / "실험결과_요약.pdf") as pdf:
        fig=plt.figure(figsize=(8.27,11.69));fig.text(.08,.94,"소단원·회귀·세 조건 답변 비교",fontsize=20,weight="bold")
        state="전체 응답 확보" if result["complete"] else "진행 중 부분 결과"
        lines=[f"{state}: 성공 {result['successful_conditions']}/{result['expected_conditions']}개",f"학습 {len(result['settings']['train_ids'])}개 · 테스트 {result['expected_questions']}개", "",
               "실제 해설 정수 벡터는 테스트 정답 정보를 제공한 진단 조건이다.","문제만 / 실제 해설 정수 벡터 / 회귀 예측 정수 벡터를 비교했다.","두 벡터 조건은 전체 어휘의 같은 정수 표현을 사용한다.", ""]
        for m in METHODS:
            a,b=result["source_key"][m],result["supplemental_key"]["methods"][m]
            lines += [NAMES[m],f"  원본 {a['correct']}/{a['graded_responses']} ({percent(a['accuracy_on_graded'])}) / 보조 {b['correct']}/{b['graded_responses']} ({percent(b['accuracy_on_graded'])})",f"  평균 입력/출력/전체 토큰: " + " / ".join(number(a['usage'][f]['successful_response_mean'],1) for f in ['prompt_token_count','candidates_token_count','total_token_count']),""]
        lines+= ["정답표 충돌 보조 점수는 사람의 인증 정답표가 아니다.","회귀의 전체 좌표 일치율은 0이 많으면 높아질 수 있다.","양수 합집합 좌표의 오차·일치율과 벡터 전체 일치도 함께 확인한다.","새 응답의 풀이 논리·교과 범위는 이 보고서에서 확정하지 않는다.","문항별 CSV와 세 풀이 비교 HTML을 함께 제공한다."]
        fig.text(.08,.87,"\n".join(lines),va="top",fontsize=10,linespacing=1.65);pdf.savefig(fig);plt.close(fig)
        for name,fig in figures:
            fig.savefig(output/f"{name}.png",dpi=160,bbox_inches="tight");fig.savefig(output/f"{name}.pdf",bbox_inches="tight");pdf.savefig(fig,bbox_inches="tight");paths.append(output/f"{name}.png");plt.close(fig)
        for folder, name in [("clustering","subunit_cluster_heatmap.png"),("regression","회귀_빈도벡터_성능.png"),("regression","정답과_정수예측_산점도.png"),("regression","문항별_벡터오차.png"),("regression","문항별_주요토큰_정답예측.png")]:
            path=run_root/folder/name
            if path.exists():
                fig,axis=plt.subplots(figsize=(11.7,8.3));axis.imshow(plt.imread(path));axis.axis("off");fig.tight_layout();pdf.savefig(fig,bbox_inches="tight");plt.close(fig)
    return paths


def html_report(result, markdown, figures):
    # Markdown 원문도 함께 제공하고, 그림은 자체 포함해 오프라인에서 볼 수 있게 한다.
    escaped=html.escape
    title="전체 응답 확보" if result["complete"] else "진행 중 부분 결과"
    rows=[]
    for m in METHODS:
        a,b=result["source_key"][m],result["supplemental_key"]["methods"][m]
        rows.append(f"<tr><td>{NAMES[m]}</td><td>{a['correct']}/{a['graded_responses']} · {percent(a['accuracy_on_graded'])}</td><td>{b['correct']}/{b['graded_responses']} · {percent(b['accuracy_on_graded'])}</td><td>{number(a['usage']['prompt_token_count']['successful_response_mean'],1)}</td><td>{number(a['usage']['candidates_token_count']['successful_response_mean'],1)}</td><td>{number(a['usage']['total_token_count']['successful_response_mean'],1)}</td></tr>")
    images="".join(f'<img alt="{escaped(p.stem)}" src="data:image/png;base64,{base64.b64encode(p.read_bytes()).decode()}">' for p in figures)
    return f'''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>소단원·회귀·세 조건 실험</title><style>body{{max-width:1150px;margin:32px auto;padding:0 20px;font:15px/1.7 system-ui;color:#111;background:white}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #aaa;padding:9px;text-align:right}}th:first-child,td:first-child{{text-align:left}}th{{background:#eee}}img{{max-width:100%;display:block;margin:24px 0}}pre{{white-space:pre-wrap;background:#f5f5f5;padding:18px}}.note{{border-left:4px solid #444;padding:12px 18px;background:#f3f3f3}}a{{color:#111}}</style><h1>소단원·회귀·세 조건 실험</h1><p><b>{title}: {result['successful_conditions']}/{result['expected_conditions']}개 응답</b></p><p class="note">실제 해설 벡터 조건은 테스트 정답 정보를 제공한 진단 조건이다. 예측 벡터만 사용하는 일반 평가와 구분한다. 두 벡터 조건은 같은 전체 정수 빈도 표현을 사용했다.</p><nav><a href="실험결과_요약.pdf">PDF 요약</a> · <a href="../generation/report.html">세 풀이 나란히 보기</a> · <a href="80문항_세조건_비교.csv">문항별 CSV</a> · <a href="../clustering/clusters/">군집별 문항</a> · <a href="../regression/token_comparison.csv">실제·예측 모든 토큰</a></nav><h2>세 조건 정확도·사용량</h2><table><tr><th>조건</th><th>원본 정답표</th><th>수학 검토 보조 점수</th><th>평균 입력</th><th>평균 출력</th><th>평균 전체</th></tr>{''.join(rows)}</table>{images}<details open><summary>군집·회귀·정답표·평가 범위 상세</summary><pre>{escaped(markdown)}</pre></details></html>'''


def build_report(run_root, output=None, conflicts_path=None):
    run_root=Path(run_root);output=Path(output) if output else run_root/"report";output.mkdir(parents=True,exist_ok=True)
    result, latest, reviewed=analyze(run_root,conflicts_path)
    (output/"three_way_summary.json").write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    markdown=markdown_report(result);(output/"실험결과_요약.md").write_text(markdown,encoding="utf-8")
    export_question_tables(output,result["test_ids"],latest,reviewed)
    figures=render_figures(result,run_root,output)
    for folder,name in [("clustering","subunit_cluster_heatmap.png"),("regression","회귀_빈도벡터_성능.png"),("regression","정답과_정수예측_산점도.png"),("regression","문항별_벡터오차.png")]:
        if (run_root/folder/name).exists():figures.append(run_root/folder/name)
    (output/"결과_한눈에.html").write_text(html_report(result,markdown,figures),encoding="utf-8")
    print(json.dumps({"output":str(output),"successful_conditions":result["successful_conditions"],"expected_conditions":result["expected_conditions"],"complete":result["complete"]},ensure_ascii=False))
    return result


def main():
    build_report(RUN_ROOT, OUTPUT)


if __name__ == "__main__":
    main()
