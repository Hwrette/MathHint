"""테스트 문항별 정답·예측 해설 빈도 벡터를 CSV·표·그림으로 비교한다."""

import csv
import json
from pathlib import Path

import torch
from torch.nn.functional import cosine_similarity


def vector_metrics(prediction, answer):
    """0인 좌표가 많다는 점을 드러내기 위해 전체와 활성 좌표를 따로 센다."""
    prediction, answer = prediction.float(), answer.float()
    error = prediction - answer
    active = (prediction != 0) | (answer != 0)
    exact = prediction == answer
    predicted_present, actual_present = prediction > 0, answer > 0
    true_positive = (predicted_present & actual_present).sum().item()
    predicted_count, actual_count = predicted_present.sum().item(), actual_present.sum().item()
    precision = true_positive / predicted_count if predicted_count else float(actual_count == 0)
    recall = true_positive / actual_count if actual_count else float(predicted_count == 0)
    return {
        "mse": error.square().mean().item(), "mae": error.abs().mean().item(),
        "cosine_similarity": cosine_similarity(prediction.reshape(1, -1), answer.reshape(1, -1)).item(),
        "coordinate_exact_rate_including_zeros": exact.float().mean().item(),
        "active_coordinate_exact_rate": exact[active].float().mean().item() if active.any() else 1.0,
        "active_coordinate_count": active.sum().item(),
        "active_coordinate_mae": error[active].abs().mean().item() if active.any() else 0.0,
        "whole_vector_exact_match": bool(exact.all()),
        "presence_precision": precision, "presence_recall": recall,
        "presence_f1": 2 * precision * recall / (precision + recall) if precision + recall else 0.0,
        "actual_frequency_sum": answer.sum().item(), "predicted_frequency_sum": prediction.sum().item(),
    }


def export_comparison(ids, vocabulary, actual, raw, rounded, mean, output, *, records=None, project_root=None):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    records = records or {}
    variants = {"raw": raw, "clipped": raw.clamp_min(0), "rounded": rounded,
                "training_mean": mean, "zero_baseline": torch.zeros_like(actual)}
    rows, token_rows = [], []
    questions = output / "questions"
    questions.mkdir(exist_ok=True)
    for i, identifier in enumerate(ids):
        row = {"id": identifier}
        for name, values in variants.items():
            row.update({name + "_" + key: value for key, value in vector_metrics(values[i], actual[i]).items()})
        rows.append(row)
        for j, token in enumerate(vocabulary):
            token_rows.append({"id": identifier, "token_index": j, "token": token,
                "actual": int(actual[i, j]), "raw_predicted": raw[i, j].item(),
                "clipped_predicted": max(0.0, raw[i, j].item()), "integer_predicted": int(rounded[i, j]),
                "integer_error": int(rounded[i, j] - actual[i, j]),
                "integer_absolute_error": abs(int(rounded[i, j] - actual[i, j]))})
        differences = sorted(token_rows[-len(vocabulary):], key=lambda d: (-d["integer_absolute_error"], d["token_index"]))
        meta = records.get(identifier, {})
        lines = [f"# {identifier}: 정답·예측 빈도 벡터", "",
            "분류: " + " / ".join(str(meta.get(key, "")) for key in ("subject", "unit", "subunit", "type")), "",
            f"정수 예측 MSE {row['rounded_mse']:.4f} · MAE {row['rounded_mae']:.4f} · 코사인 {row['rounded_cosine_similarity']:.4f}",
            f"전체 좌표 일치율 {row['rounded_coordinate_exact_rate_including_zeros']:.2%} · 활성 좌표 일치율 {row['rounded_active_coordinate_exact_rate']:.2%}",
            "활성 좌표는 정답 또는 정수 예측이 0이 아닌 칸이다. 둘 다 0인 칸은 제외한다.", ""]
        problem_path = Path(project_root) / "data/processed/problems" / (identifier + ".txt") if project_root else None
        if problem_path and problem_path.exists():
            lines += ["## 문제", "", problem_path.read_text(encoding="utf-8"), ""]
        lines += ["## 오차가 큰 토큰 25개", "", "|토큰|정답 빈도|원시 예측|정수 예측|정수 오차|", "|---|---:|---:|---:|---:|"]
        for item in differences[:25]:
            token = item["token"].replace("|", "\\|")
            lines.append(f"|`{token}`|{item['actual']}|{item['raw_predicted']:.4f}|{item['integer_predicted']}|{item['integer_error']}|")
        lines += ["", "전체 어휘의 정답·예측값은 상위 폴더의 token_comparison.csv에서 확인할 수 있다."]
        (questions / (identifier + ".md")).write_text("\n".join(lines) + "\n", encoding="utf-8")
    for filename, values in [("vector_metrics.csv", rows), ("token_comparison.csv", token_rows)]:
        with (output / filename).open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(values[0]))
            writer.writeheader()
            writer.writerows(values)
    aggregate = {}
    for name, values in variants.items():
        metrics = vector_metrics(values, actual)
        metrics["flattened_cosine_similarity"] = metrics.pop("cosine_similarity")
        metrics["mean_cosine_similarity"] = cosine_similarity(values.float(), actual.float(), dim=1).mean().item()
        metrics["whole_vector_exact_count"] = int((values == actual).all(dim=1).sum())
        metrics["whole_vector_exact_rate"] = metrics["whole_vector_exact_count"] / len(ids)
        aggregate[name] = metrics
    summary = {"test_ids": ids, "test_count": len(ids), "vocabulary_size": len(vocabulary),
        "rounding": "negative values -> 0, then floor(x + 0.5), integer",
        "actual_zero_coordinate_rate": (actual == 0).float().mean().item(),
        "metrics": aggregate, "note": "좌표 일치율은 문제 정답률이 아니다. 0이 많은 벡터이므로 활성 좌표 지표도 함께 본다."}
    (output / "vector_comparison_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    _plots(actual, raw, rounded, mean, ids, vocabulary, rows, output)
    return summary


def _plots(actual, raw, rounded, mean, ids, vocabulary, rows, output):
    import os
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/mathhint-mpl")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    font = Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=str(font)).get_name()
    plt.rcParams.update({"axes.unicode_minus": False, "axes.spines.top": False, "axes.spines.right": False, "font.size": 9})

    def save(fig, name):
        fig.tight_layout()
        fig.savefig(output / (name + ".png"), dpi=160, bbox_inches="tight")
        fig.savefig(output / (name + ".pdf"), bbox_inches="tight")
        plt.close(fig)

    values = [mean, raw, raw.clamp_min(0), rounded]
    labels = ["학습 평균", "원시 예측", "음수→0", "정수 반올림"]
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.6))
    for ax, key, title in zip(axes, ["mse", "mae", "mean_cosine_similarity"], ["MSE ↓", "MAE ↓", "코사인 유사도 ↑"]):
        scores = [cosine_similarity(v.float(), actual.float(), dim=1).mean().item() if key == "mean_cosine_similarity" else vector_metrics(v, actual)[key] for v in values]
        bars = ax.bar(labels, scores, color=[".85", ".65", ".45", ".2"], edgecolor="black", linewidth=.6)
        ax.bar_label(bars, fmt="%.3f", fontsize=8)
        ax.set_title(title)
        ax.tick_params(axis="x", labelrotation=20)
        ax.set_ylim(0, max(scores) * 1.16 if max(scores) else 1)
    fig.suptitle(f"같은 테스트 {len(ids)}문항 · 정답 해설 빈도 벡터 예측")
    save(fig, "회귀_빈도벡터_성능")

    pairs, counts = torch.unique(torch.stack([actual.flatten().long(), rounded.flatten()], dim=1), dim=0, return_counts=True)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, zoom in zip(axes, [False, True]):
        selected = ((pairs <= 10).all(dim=1)) if zoom else torch.ones(len(pairs), dtype=torch.bool)
        ax.scatter(pairs[selected, 0], pairs[selected, 1], s=12 + counts[selected].float().log1p() * 10, color=".5", edgecolors="black", linewidths=.4, alpha=.75)
        maximum = 10 if zoom else max(1, int(pairs.max()))
        ax.plot([0, maximum], [0, maximum], color="black", linestyle="--", linewidth=1)
        ax.set(xlabel="정답 빈도", ylabel="정수 예측 빈도", title="0~10 확대" if zoom else "전체 좌표 범위")
        ax.set_xlim(-.3, maximum + .5)
        ax.set_ylim(-.3, maximum + .5)
    fig.suptitle("정답과 정수 예측 비교 · 점 크기는 같은 값 쌍의 좌표 수")
    save(fig, "정답과_정수예측_산점도")

    worst = sorted(rows, key=lambda row: row["rounded_mae"], reverse=True)[:20]
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.barh([row["id"] for row in reversed(worst)], [row["rounded_mae"] for row in reversed(worst)], color=".5", edgecolor="black", linewidth=.5)
    ax.set(xlabel="정수 예측 MAE", title="테스트 문항별 벡터 오차가 큰 순서 (최대 20개)")
    save(fig, "문항별_벡터오차")

    selected = actual.sum(dim=0).argsort(descending=True)[:min(20, len(vocabulary))]
    fig, axes = plt.subplots(1, 2, figsize=(14, max(5, len(ids) * .16)))
    maximum = max(1.0, actual[:, selected].max().item(), rounded[:, selected].max().item())
    for ax, values, title in zip(axes, [actual, rounded], ["정답 빈도", "정수 예측 빈도"]):
        image = ax.imshow(values[:, selected], cmap="Greys", aspect="auto", vmin=0, vmax=maximum)
        ax.set_xticks(range(len(selected)), [vocabulary[j] for j in selected], rotation=65, ha="right", fontsize=7)
        step = max(1, len(ids) // 20)
        ax.set_yticks(range(0, len(ids), step), ids[::step], fontsize=7)
        ax.set_title(title)
        fig.colorbar(image, ax=ax, shrink=.7)
    fig.suptitle("테스트 정답 빈도 합 상위 20토큰 (표시용 선택, 모델·가이드 설정에 사용하지 않음)")
    save(fig, "문항별_주요토큰_정답예측")
