"""군집별 문항 목록과 실제 소단원 분포를 표·문서·그림으로 저장한다."""

from collections import Counter
import csv
import json
import os
from pathlib import Path


def save_cluster_reports(root, output, documents, n_clusters):
    output = Path(output)
    folder = output / "clusters"
    folder.mkdir(parents=True, exist_ok=True)
    summaries = []
    labels = sorted({row["actual_labels"]["subunit"] for row in documents})
    counts = {part: [[0] * n_clusters for _ in labels] for part in ("train", "test")}
    label_index = {label: i for i, label in enumerate(labels)}
    for row in documents:
        counts[row["split"]][label_index[row["actual_labels"]["subunit"]]][row["cluster"]] += 1

    for cluster in range(n_clusters):
        members = [row for row in documents if row["cluster"] == cluster]
        groups = {part: [row for row in members if row["split"] == part] for part in ("train", "test")}
        distribution = {part: Counter(row["actual_labels"]["subunit"] for row in rows) for part, rows in groups.items()}
        majority = members[0]["train_majority_predicted_labels"]["subunit"] if members else None
        summaries.append({"cluster": cluster, "train_count": len(groups["train"]), "test_count": len(groups["test"]),
                          "train_majority_subunit": majority,
                          "train_ids": [row["id"] for row in groups["train"]],
                          "test_ids": [row["id"] for row in groups["test"]],
                          "subunit_distribution": distribution})
        lines = [f"# 군집 {cluster:02d}", "", f"학습 {len(groups['train'])}문항 · 테스트 {len(groups['test'])}문항", "",
                 "학습 다수 소단원: " + (majority or "학습 문항 없음"), "",
                 "군집 번호는 임의 번호이며 소단원 번호가 아니다. 다수 라벨은 학습에서만 정했다.", ""]
        for part, title in [("train", "학습"), ("test", "테스트")]:
            lines += [f"## {title} 소단원 구성", "", "| 소단원 | 문항 수 |", "|---|---:|"]
            lines += [f"| {label} | {count} |" for label, count in distribution[part].most_common()]
            lines += ["", f"## {title} 문항", ""]
            if not groups[part]:
                lines += ["문항 없음", ""]
            for row in groups[part]:
                problem = Path(root) / "data/processed/problems" / f"{row['id']}.txt"
                lines += [f"### {row['id']}", "", "- 소단원: " + row["actual_labels"]["subunit"],
                          "- 유형: " + row["type"], "- 출처: " + row["source"],
                          f"- 원래 번호: {row['original_number']} / 현재 번호: {row['current_number']}", "",
                          problem.read_text(encoding="utf-8-sig") if problem.exists() else "문제 본문 파일 없음", ""]
        (folder / f"cluster_{cluster:02d}.md").write_text("\n".join(lines), encoding="utf-8")

    (output / "cluster_groups.json").write_text(json.dumps({"n_clusters": n_clusters, "clusters": summaries}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (output / "cluster_summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["cluster", "train_count", "test_count", "train_majority_subunit", "train_subunits", "test_subunits"])
        for row in summaries:
            writer.writerow([row[key] for key in ("cluster", "train_count", "test_count", "train_majority_subunit")] +
                            [json.dumps(row["subunit_distribution"][part], ensure_ascii=False) for part in ("train", "test")])
    with (output / "cluster_assignments.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        fields = ["id", "split", "cluster", "curriculum", "unit", "subunit", "type", "source", "source_file", "original_number", "current_number"]
        writer = csv.writer(stream)
        writer.writerow(fields + ["train_majority_subunit", "subunit_matches_train_majority"])
        for row in documents:
            predicted = row["train_majority_predicted_labels"]["subunit"]
            writer.writerow([row[key] for key in fields] + [predicted, predicted == row["actual_labels"]["subunit"]])
    with (output / "subunit_cluster_counts.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["split", "subunit"] + [f"cluster_{i:02d}" for i in range(n_clusters)])
        for part in ("train", "test"):
            writer.writerows([part, label, *counts[part][i]] for i, label in enumerate(labels))
    lines = ["# 실제 소단원 수를 사용한 군집화", "",
             f"군집 {n_clusters}개. 학습 {sum(row['split'] == 'train' for row in documents)}문항 / 테스트 {sum(row['split'] == 'test' for row in documents)}문항.", "",
             "소단원은 과목·단원·소단원의 전체 경로로 구분했다. 학습에서 만든 중심과 다수 라벨만 테스트에 적용했다.", "",
             "[일치도 수치](clustering_metrics.json) · [문항별 배정 CSV](cluster_assignments.csv) · [소단원 분포 그림](subunit_cluster_heatmap.png)", "",
             "| 군집 | 학습 | 테스트 | 학습 다수 소단원 | 문항 목록 |", "|---:|---:|---:|---|---|"]
    for row in summaries:
        lines.append(f"| {row['cluster']} | {row['train_count']} | {row['test_count']} | {row['train_majority_subunit'] or '학습 문항 없음'} | [보기](clusters/cluster_{row['cluster']:02d}.md) |")
    (output / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    plot_subunits(output, labels, counts, n_clusters)


def plot_subunits(output, labels, counts, n_clusters):
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/mathhint-clustering-mpl")
    os.environ.setdefault("XDG_CACHE_HOME", "/tmp/mathhint-clustering-cache")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    font_path = Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
    if font_path.exists():
        font_manager.fontManager.addfont(str(font_path))
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=str(font_path)).get_name()
    fig, axes = plt.subplots(1, 2, figsize=(19, max(7, .32 * len(labels))), constrained_layout=True)
    maximum = max(value for matrix in counts.values() for row in matrix for value in row) or 1
    for ax, part, title in zip(axes, ("train", "test"), ("학습", "테스트")):
        image = ax.imshow(counts[part], cmap="Greys", vmin=0, vmax=maximum, aspect="auto")
        ax.set_title(f"{title} 실제 소단원 × 군집 (k={n_clusters})")
        ax.set_xticks(range(n_clusters), [str(i) for i in range(n_clusters)], fontsize=7)
        ax.set_yticks(range(len(labels)), labels, fontsize=7)
        ax.set_xlabel("군집 번호")
        for row, values in enumerate(counts[part]):
            for column, count in enumerate(values):
                if count:
                    ax.text(column, row, str(count), ha="center", va="center", fontsize=7,
                            color="white" if count > maximum / 2 else "black")
    fig.colorbar(image, ax=axes, label="문항 수", shrink=.7)
    for suffix in ("png", "pdf"):
        fig.savefig(Path(output) / f"subunit_cluster_heatmap.{suffix}", dpi=160)
    plt.close(fig)
