"""문제만 / 실제 해설 빈도 / 회귀 예측 빈도의 세 조건을 같은 테스트에서 비교한다.

실제 해설 벡터 조건은 테스트 정답 정보를 제공한 실험이다. 예측 모델의 실력으로
해석하지 않는다. 두 벡터 조건은 같은 정수 변환·전체 어휘·입력 문구를 사용한다.
상단 설정을 확인하고 실행한다. RUN_API=False이면 입력과 기존 대조군만 준비한다.
"""

import csv
import html
import json
import math
import os
from pathlib import Path

if __package__:
    from . import CompareGeneration as comparison
    from .RateLimitedComparison import GlobalRateLimiter, DailyQuotaStop
else:
    import CompareGeneration as comparison
    from RateLimitedComparison import GlobalRateLimiter, DailyQuotaStop


ROOT = Path(__file__).resolve().parents[1]
RUN_ROOT = ROOT / "outputs/subunit_threeway"
PREDICTIONS = RUN_ROOT / "regression/regression_predictions.json"
OUTPUT = RUN_ROOT / "generation"
PREVIOUS = ROOT / "results/model_comparison_2026-11-07/03_Gemini비교"
BASELINE_CONFIG = PREVIOUS / "실험설정.json"
BASELINE_RECORDS = PREVIOUS / "원본응답_160개.jsonl"
MODEL = "gemini-3.1-flash-lite"
THINKING_LEVEL = "minimal"
TEMPERATURE = 0.0
MAX_OUTPUT_TOKENS = 8192
RUN_API = False
INTERVAL = 5.0
WORKERS = 2
LIMIT = None

METHODS = ("baseline", "oracle_hint", "regression_hint")
METHOD_NAMES = {"baseline": "문제만 입력", "oracle_hint": "실제 정답·해설 벡터 제공", "regression_hint": "회귀 예측 벡터 제공"}
# 여섯 순서를 반복하면 기존 대조군을 재사용할 때도 두 새 조건의 선후가 균형을 이룬다.
ORDERS = ((0, 1, 2), (0, 2, 1), (1, 0, 2), (1, 2, 0), (2, 0, 1), (2, 1, 0))


def integer_vector(values):
    """음수를 0으로 만들고 0.5 이상을 올리는 일반적인 정수 반올림을 한다."""
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in values):
        raise ValueError("빈도 벡터는 유한한 숫자여야 합니다.")
    return [math.floor(max(0, value) + .5) for value in values]


def serialize_vector(vocabulary, values):
    if len(vocabulary) != len(values) or len(set(vocabulary)) != len(vocabulary):
        raise ValueError("어휘 목록과 벡터 차원이 다르거나 어휘가 중복됩니다.")
    vector = integer_vector(values)
    mapping = {token: count for token, count in zip(vocabulary, vector) if count > 0}
    text = "\n\n[해설 토큰 빈도 벡터]\n" + json.dumps(mapping, ensure_ascii=False, separators=(",", ":"))
    return text, {"transform": "clip_min_0_round_half_up_integer_omit_zeros", "vocabulary_size": len(vector),
                  "transmitted_coordinates": len(mapping), "integer_vector": vector, "mapping": mapping}


def prepare_plan(project, predictions_path, *, model=MODEL, thinking_level=THINKING_LEVEL,
                 temperature=TEMPERATURE, max_output_tokens=MAX_OUTPUT_TOKENS,
                 system_instruction=comparison.DEFAULT_SYSTEM, attempts=2):
    """기존 문항 연결 검사를 재사용하고, 실제 해설 벡터는 oracle 조건에만 연결한다."""
    project, predictions_path = Path(project), Path(predictions_path)
    config, pairs = comparison.prepare_plan(project, predictions_path, model=model, thinking_level=thinking_level,
        temperature=temperature, max_output_tokens=max_output_tokens, system_instruction=system_instruction,
        attempts=attempts, hint_mode="full_vector")
    predicted = comparison.read_json(predictions_path)
    actual_path = project / "data/vectors/solutions/test_vectors.json"
    actual = comparison.read_json(actual_path)
    vocabulary_path = project / "data/vectors/solutions/vocabulary.json"
    vocabulary = comparison.read_json(vocabulary_path)
    if predicted["vocabulary"] != vocabulary or actual["generation_id"] != config["generation_id"]:
        raise ValueError("정답·예측 벡터의 어휘 또는 데이터 버전이 다릅니다.")
    if [row["id"] for row in actual["documents"]] != config["test_ids"]:
        raise ValueError("실제 해설 벡터의 행이 테스트 ID 순서와 다릅니다.")
    predictions = {row["id"]: row["predicted_vector"] for row in predicted["documents"]}
    answers = {row["id"]: row["vector"] for row in actual["documents"]}
    baselines = {row["id"]: row for row in pairs if row["method"] == "baseline"}
    plan, hashes = [], []
    for index, identifier in enumerate(config["test_ids"]):
        base = baselines[identifier]
        arms = []
        for method in METHODS:
            text, hint = "", None
            if method != "baseline":
                values = answers[identifier] if method == "oracle_hint" else predictions[identifier]
                if method == "oracle_hint" and any(value < 0 or value != int(value) for value in values):
                    raise ValueError("실제 해설 빈도는 0 이상의 정수여야 합니다.")
                text, hint = serialize_vector(vocabulary, values)
                hint["source"] = "actual_reference" if method == "oracle_hint" else "regression_prediction"
            content = base["problem_text"] + text
            arms.append({**base, "method": method, "input_text": content, "input_sha256": comparison.digest(content),
                         "hint": hint, "uses_test_reference_vector": method == "oracle_hint"})
        plan.extend(arms[position] for position in ORDERS[index % len(ORDERS)])
        hashes.append({"id": identifier, **{row["method"]: row["input_sha256"] for row in arms},
                       "reference_sha256": comparison.digest([base["reference"], base["reference_solution"]])})
    config.update(schema_version=2, methods=list(METHODS), hint_mode="integer_full_vector", hint_top_k=None,
        hint_transform="clip_min_0_round_half_up_integer_omit_zeros", condition_order="six_balanced_permutations",
        oracle_caveat="Actual held-out reference-solution token counts are provided only to oracle_hint; this is privileged information.",
        actual_solution_vectors_sha256=comparison.file_hash(actual_path), vocabulary_sha256=comparison.file_hash(vocabulary_path),
        inputs=hashes, runner_sha256=comparison.file_hash(Path(__file__)),
        shared_runner_sha256=comparison.file_hash(Path(comparison.__file__)))
    return config, plan


def reuse_baselines(output, config, plan, source_config_path, source_records_path):
    """동일 입력·설정의 성공 기본 응답만 원래 시각·사용량과 함께 가져온다."""
    source = comparison.read_json(Path(source_config_path))
    old_config, old_id = source["config"], source["config_id"]
    if comparison.digest(old_config) != old_id:
        raise ValueError("기존 대조군 설정의 해시가 다릅니다.")
    for field in ("model", "thinking_level", "temperature", "max_output_tokens", "system_instruction",
                  "generation_id", "train_ids", "test_ids", "grader_sha256"):
        if old_config.get(field) != config.get(field):
            raise ValueError("기존 대조군 설정 불일치: " + field)
    previous = {}
    for line in Path(source_records_path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            row = json.loads(line)
            if row["config_id"] != old_id:
                raise ValueError("기존 응답의 설정 ID가 다릅니다.")
            previous[row["id"], row["method"]] = row
    config_id = comparison.initialize_run(output, config, plan)
    completed = comparison.load_completed(output, config_id)
    candidates = []
    for item in plan:
        row = previous.get((item["id"], "baseline"))
        if item["method"] != "baseline" or row is None or row["status"] != "success":
            continue
        for field in ("input_text", "input_sha256", "system_instruction", "reference", "reference_answer_text", "reference_solution", "problem_text"):
            if row.get(field) != item.get(field):
                raise ValueError("기존 대조군 문항 불일치: " + item["id"] + "/" + field)
        if completed.get((item["id"], "baseline"), {}).get("status") != "success":
            candidates.append((item, row))
    for item, row in candidates:
        comparison.save_result(output, {**row, "config_id": config_id, "uses_test_reference_vector": False,
            "response_origin": "reused_control", "provenance": {"source_config": str(source_config_path),
                "source_records": str(source_records_path), "source_config_id": old_id,
                "source_record_sha256": comparison.digest(row), "imported_at": comparison.utc_now()}})
    return len(candidates)


def render_reports(output, records, config, *, charts=False):
    """세 조건을 같은 표와 세 열의 문항별 화면으로 내보낸다."""
    summary = {"expected_questions": len(config["test_ids"]), "methods": {}, "oracle_caveat": config["oracle_caveat"]}
    for method in METHODS:
        rows = [row for row in records if row["method"] == method]
        success = [row for row in rows if row["status"] == "success"]
        graded = [row for row in success if row["evaluation"].get("correct") is not None]
        correct = sum(row["evaluation"]["correct"] is True for row in graded)
        usage = {}
        for field in comparison.USAGE_FIELDS:
            values = [row["usage"].get(field) for row in success]
            known = [value for value in values if value is not None]
            usage[field] = {"sum": sum(known) if values and len(known) == len(values) else None,
                            "known_sum": sum(known), "mean": sum(known) / len(known) if known else None,
                            "provided": len(known), "missing": len(values) - len(known)}
        summary["methods"][method] = {"recorded": len(rows), "successful": len(success), "graded": len(graded),
            "correct": correct, "accuracy_on_graded": correct / len(graded) if graded else None,
            "correct_per_expected": correct / len(config["test_ids"]), "usage": usage,
            "reused_controls": sum(row.get("response_origin") == "reused_control" for row in rows)}
    comparison.write_json(output / "summary.json", summary)
    with (output / "comparison.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        fields = ["id", "method", "uses_test_reference_vector", "status", "reference_answer_text", "predicted_answer", "correct", *comparison.USAGE_FIELDS, "input_text", "output_text"]
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for row in records:
            writer.writerow({**{f: row.get(f) for f in fields if f not in comparison.USAGE_FIELDS},
                **{f: row["usage"].get(f) for f in comparison.USAGE_FIELDS},
                "predicted_answer": row["evaluation"].get("predicted_answer"), "correct": row["evaluation"].get("correct")})
    escaped = lambda value: html.escape(str(value))
    indexed = {(row["id"], row["method"]): row for row in records}
    cards = []
    for identifier in config["test_ids"]:
        columns = []
        for method in METHODS:
            row = indexed.get((identifier, method))
            content = "미실행" if row is None else (f'<p>원본 정답: {escaped(row["reference_answer_text"])} / 판정: {escaped(row["evaluation"].get("correct"))} / 전체 토큰: {escaped(row["usage"].get("total_token_count"))}</p>'
                f'<details><summary>실제 입력</summary><pre>{escaped(row["input_text"])}</pre></details>'
                f'<pre>{escaped(row["output_text"] or row.get("error", ""))}</pre>'
                f'<details><summary>원본 정답·해설</summary><pre>{escaped(row["reference_solution"])}</pre></details>')
            columns.append(f'<section><h3>{METHOD_NAMES[method]}</h3>{content}</section>')
        cards.append(f'<article data-id="{escaped(identifier)}"><h2>{escaped(identifier)}</h2><div class="columns">' + "".join(columns) + '</div></article>')
    document = '<!doctype html><html lang="ko"><meta charset="utf-8"><title>세 조건 풀이 비교</title><style>body{font:15px/1.6 system-ui;max-width:1700px;margin:25px auto;padding:20px;color:#111}.columns{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}article{border-top:2px solid #333;margin-top:25px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit}details{border:1px solid #ccc;padding:8px}section{min-width:0}@media(max-width:900px){.columns{grid-template-columns:1fr}}</style><h1>세 조건 풀이 비교</h1><p>실제 해설 벡터 조건은 테스트 정답 정보를 제공한 조건이며 예측 모델의 성능으로 해석하지 않습니다. 표시된 정오답은 원본 정답표 기준이며 풀이 타당성은 별도 평가입니다.</p><input id="search" placeholder="문항 ID 검색">' + "".join(cards) + '<script>document.querySelector("#search").oninput=e=>document.querySelectorAll("article").forEach(a=>a.hidden=!a.dataset.id.includes(e.target.value));</script></html>'
    (output / "report.html").write_text(document, encoding="utf-8")
    return summary


def prepare(output, config, plan, source_config_path=BASELINE_CONFIG, source_records_path=BASELINE_RECORDS):
    output = Path(output)
    comparison.initialize_run(output, config, plan)
    imported = reuse_baselines(output, config, plan, source_config_path, source_records_path) if source_config_path else 0
    render_reports(output, list(comparison.load_completed(output, comparison.digest(config)).values()), config)
    return imported


def run_experiment(output, config, plan, *, api_key, interval=INTERVAL, workers=WORKERS,
                   limit=None, retry_errors=True, request_function=None):
    """기존의 저장·재개 엔진과 전역 속도 제한을 재사용한다."""
    output = Path(output); comparison.initialize_run(output, config, plan)
    execution_id = comparison.utc_now().replace(":", "").replace(".", "_")
    directory = output / "execution_runs"; directory.mkdir(exist_ok=True)
    execution = {"config_id": comparison.digest(config), "started_at": comparison.utc_now(), "status": "running",
        "wrapper_sha256": comparison.file_hash(Path(__file__)), "interval": interval, "workers": workers,
        "retry_errors": retry_errors, "limit": limit}
    def event(event):
        with (directory / (execution_id + "_rate_events.jsonl")).open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(event, ensure_ascii=False) + "\n")
    stop_file = output / "stop_requested"
    limiter = GlobalRateLimiter(interval, event_handler=event, stop_requested=stop_file.exists)
    request = request_function or comparison.make_request(config, api_key)
    def generate(item, current_config, current_id, key):
        if limiter.daily_exhausted:
            raise DailyQuotaStop("일일 한도가 소진되어 다음 요청을 보내지 않습니다.")
        result = comparison.generate_one(item, current_config, current_id, key,
            request_function=lambda text: limiter.request(request, text))
        result["rate_limited_execution_id"] = execution_id
        if limiter.daily_exhausted and (result["status"].startswith("stopped_") or any(a.get("code") == 429 for a in result["attempts"])):
            result.update(status="api_error", daily_quota_exhausted=True)
        return result
    try:
        result = comparison.run_requests(output, config, plan, api_key=api_key, workers=workers, limit=limit,
            retry_errors=retry_errors, stop_file=stop_file, generate_function=generate, report_function=render_reports)
        execution["status"] = "completed"
        return result
    except comparison.RequestedStop:
        execution["status"] = "daily_quota_exhausted" if limiter.daily_exhausted else "stopped_gracefully"
        raise
    except BaseException as error:
        execution.update(status="interrupted_or_failed", error_type=type(error).__name__, error_message=str(error).replace(api_key, "[REDACTED]"))
        raise
    finally:
        execution["completed_at"] = comparison.utc_now()
        comparison.write_json(directory / (execution_id + ".json"), execution)


def main():
    config, plan = prepare_plan(ROOT, PREDICTIONS)
    count = prepare(OUTPUT, config, plan)
    print(f"테스트 {len(config['test_ids'])}개 × 세 조건 준비 / 기존 기본 응답 {count}개 가져옴")
    if RUN_API:
        from dotenv import load_dotenv
        load_dotenv(ROOT / ".env", override=False)
        key = os.getenv("GEMINI_API_KEY")
        if not key:
            raise SystemExit("GEMINI_API_KEY가 필요합니다.")
        run_experiment(OUTPUT, config, plan, api_key=key, limit=LIMIT)


if __name__ == "__main__":
    main()
