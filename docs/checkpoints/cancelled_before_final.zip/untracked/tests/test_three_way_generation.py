"""세 조건의 정보 접근·반올림·기존 대조군 재사용·재개를 확인한다."""

import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

from mathhint_solver import CompareGeneration as comparison
from mathhint_solver import ThreeWayGeneration as three


class ThreeWayTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.ids = ["q1", "q2"]
        vocabulary = ["actual_only", "predicted_only", "both", "negative", "half"]
        for folder in ["splits", "problems", "solutions"]:
            (self.root / "data/processed" / folder).mkdir(parents=True)
        metadata = []
        for identifier in self.ids:
            (self.root / f"data/processed/problems/{identifier}.txt").write_text("$6 \\times 7$의 값은?", encoding="utf-8")
            (self.root / f"data/processed/solutions/{identifier}.txt").write_text("REFERENCE_PROSE_SECRET 정답42", encoding="utf-8")
            metadata.append({"id": identifier, "answer_text": "$42$", "subject": "SUBJECT_SECRET",
                             "unit": "UNIT_SECRET", "type": "TYPE_SECRET", "source": "SOURCE_SECRET"})
        comparison.write_json(self.root / "data/processed/metadata.json", {"generation_id": "fixture", "records": metadata})
        comparison.write_json(self.root / "data/processed/splits/train.json", ["train1"])
        comparison.write_json(self.root / "data/processed/splits/test.json", self.ids)
        comparison.write_json(self.root / "data/vectors/solutions/vocabulary.json", vocabulary)
        self.actual_path = self.root / "data/vectors/solutions/test_vectors.json"
        comparison.write_json(self.actual_path, {"generation_id": "fixture", "documents": [
            {"id": identifier, "vector": [11, 0, 7, 0, 0]} for identifier in self.ids]})
        self.predictions = self.root / "predictions.json"
        comparison.write_json(self.predictions, {"generation_id": "fixture", "train_ids": ["train1"], "vocabulary": vocabulary,
            "documents": [{"id": identifier, "predicted_vector": [0, 1.49, 2.5, -2, .5],
                           "actual_vector": [999991] * 5} for identifier in self.ids]})
        self.config, self.plan = three.prepare_plan(self.root, self.predictions, model="fixture_model", max_output_tokens=100)

    def tearDown(self):
        self.temporary.cleanup()

    @staticmethod
    def response():
        return SimpleNamespace(text="최종정답: 42", usage_metadata=SimpleNamespace(
            prompt_token_count=10, candidates_token_count=20, thoughts_token_count=None, total_token_count=30),
            candidates=[SimpleNamespace(finish_reason="STOP")], model_version="fixture_model", response_id="fixture")

    def test_round_half_up_and_identical_neutral_hint_format(self):
        self.assertEqual(three.integer_vector([-1, 0, .49, .5, 1.5, 2.5]), [0, 0, 0, 1, 2, 3])
        text1, _ = three.serialize_vector(["token"], [2.5])
        text2, _ = three.serialize_vector(["token"], [3])
        self.assertEqual(text1, text2)
        self.assertNotIn("정답", text1)
        self.assertNotIn("예측", text1)

    def test_only_oracle_receives_true_vector_and_no_arm_receives_reference_prose(self):
        self.assertEqual(len(self.plan), 6)
        by_method = {row["method"]: row for row in self.plan if row["id"] == "q1"}
        self.assertEqual(by_method["baseline"]["input_text"], by_method["baseline"]["problem_text"])
        self.assertEqual(by_method["oracle_hint"]["hint"]["mapping"], {"actual_only": 11, "both": 7})
        self.assertEqual(by_method["regression_hint"]["hint"]["mapping"], {"predicted_only": 1, "both": 3, "half": 1})
        for row in self.plan:
            for secret in ["REFERENCE_PROSE_SECRET", "SUBJECT_SECRET", "UNIT_SECRET", "TYPE_SECRET", "SOURCE_SECRET", "999991"]:
                self.assertNotIn(secret, row["input_text"])
            self.assertEqual(row["uses_test_reference_vector"], row["method"] == "oracle_hint")

    def test_all_coordinates_are_available_and_not_top_twenty(self):
        _, hint = three.serialize_vector([f"t{i}" for i in range(25)], [1] * 25)
        self.assertEqual(hint["transmitted_coordinates"], 25)
        self.assertEqual(hint["integer_vector"], [1] * 25)

    def test_changed_actual_reference_vector_changes_only_oracle_inputs_and_config(self):
        changed = comparison.read_json(self.actual_path)
        changed["documents"][0]["vector"][0] = 12
        comparison.write_json(self.actual_path, changed)
        config, plan = three.prepare_plan(self.root, self.predictions, model="fixture_model", max_output_tokens=100)
        self.assertNotEqual(comparison.digest(config), comparison.digest(self.config))
        before = {(row["id"], row["method"]): row["input_text"] for row in self.plan}
        after = {(row["id"], row["method"]): row["input_text"] for row in plan}
        self.assertNotEqual(before["q1", "oracle_hint"], after["q1", "oracle_hint"])
        self.assertEqual(before["q1", "regression_hint"], after["q1", "regression_hint"])
        self.assertEqual(before["q1", "baseline"], after["q1", "baseline"])

    def test_actual_vector_id_order_must_match_fixed_test_ids(self):
        changed = comparison.read_json(self.actual_path)
        changed["documents"].reverse()
        comparison.write_json(self.actual_path, changed)
        with self.assertRaises(ValueError):
            three.prepare_plan(self.root, self.predictions)

    def test_all_six_orders_balance_position_and_relative_hint_order(self):
        orders = [[three.METHODS[i] for i in order] for order in three.ORDERS]
        for method in three.METHODS:
            self.assertEqual([sum(order.index(method) == position for order in orders) for position in range(3)], [2, 2, 2])
        self.assertEqual(sum(order.index("oracle_hint") < order.index("regression_hint") for order in orders), 3)

    def test_reused_baselines_keep_actual_output_usage_time_and_are_not_repeated(self):
        source, output = self.root / "source", self.root / "new"
        config, plan = comparison.prepare_plan(self.root, self.predictions, model="fixture_model", thinking_level="minimal",
                                               temperature=0., max_output_tokens=100)
        source_id = comparison.initialize_run(source, config, plan)
        originals = []
        for item in plan:
            if item["method"] == "baseline":
                row = comparison.generate_one(item, config, source_id, "fixture", lambda _: self.response())
                comparison.save_result(source, row); originals.append(row)
        self.assertEqual(three.prepare(output, self.config, self.plan, source / "config.json", source / "responses.jsonl"), 2)
        self.assertEqual(three.prepare(output, self.config, self.plan, source / "config.json", source / "responses.jsonl"), 0)
        rows = comparison.load_completed(output, comparison.digest(self.config))
        for original in originals:
            row = rows[original["id"], "baseline"]
            self.assertEqual(row["response_origin"], "reused_control")
            for field in ["output_text", "usage", "attempts", "started_at", "completed_at"]:
                self.assertEqual(row[field], original[field])
        originals[-1]["input_text"] += "changed"
        comparison.save_result(source, originals[-1])
        with self.assertRaises(ValueError):
            three.prepare(self.root / "bad", self.config, self.plan, source / "config.json", source / "responses.jsonl")
        self.assertFalse((self.root / "bad/responses.jsonl").exists())

    def test_three_arm_resume_and_unknown_usage_use_existing_durable_engine(self):
        output = self.root / "run"; calls = []
        def request(text):
            calls.append(text)
            return self.response()
        limiter = SimpleNamespace(daily_exhausted=False, request=lambda function, text: function(text))
        with patch.object(three, "GlobalRateLimiter", return_value=limiter):
            three.run_experiment(output, self.config, self.plan, api_key="fixture", limit=1, workers=1, request_function=request)
            self.assertEqual(len(calls), 3)
            three.run_experiment(output, self.config, self.plan, api_key="fixture", workers=1, request_function=request)
        self.assertEqual(len(calls), 6)
        rows = comparison.load_completed(output, comparison.digest(self.config))
        self.assertEqual(len(rows), 6)
        summary = comparison.read_json(output / "summary.json")
        self.assertEqual(set(summary["methods"]), set(three.METHODS))
        self.assertTrue(all(row["correct"] == 2 for row in summary["methods"].values()))
        self.assertIsNone(summary["methods"]["oracle_hint"]["usage"]["thoughts_token_count"]["sum"])
        self.assertEqual(comparison.METHODS, ("baseline", "regression_hint"))


if __name__ == "__main__":
    unittest.main()
