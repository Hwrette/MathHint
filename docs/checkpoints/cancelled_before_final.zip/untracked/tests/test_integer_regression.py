"""빈도 반올림과 0 좌표가 지표를 부풀리는 문제를 확인한다."""

import unittest

try:
    import torch
except ModuleNotFoundError:
    torch = None

if torch is not None:
    from mathhint_learning.TorchRegression import integer_counts
    from mathhint_learning.VectorComparison import vector_metrics


@unittest.skipIf(torch is None, "Requires torch")
class IntegerRegressionTests(unittest.TestCase):
    def test_round_half_up_and_clip_negative_values(self):
        prediction = torch.tensor([-4.2, -.5, 0., .49, .5, 1.5, 2.5, 3.49])
        rounded = integer_counts(prediction)
        self.assertEqual(rounded.dtype, torch.int64)
        self.assertEqual(rounded.tolist(), [0, 0, 0, 0, 1, 2, 3, 3])
        self.assertEqual(prediction[0].item(), torch.tensor(-4.2).item())

    def test_active_coordinate_accuracy_excludes_shared_zeros(self):
        actual = torch.tensor([0., 0., 0., 2.])
        metrics = vector_metrics(torch.zeros(4), actual)
        self.assertEqual(metrics["coordinate_exact_rate_including_zeros"], .75)
        self.assertEqual(metrics["active_coordinate_exact_rate"], 0.)
        self.assertEqual(metrics["active_coordinate_count"], 1)
        self.assertFalse(metrics["whole_vector_exact_match"])
        self.assertEqual(metrics["presence_f1"], 0.)

    def test_presence_agreement_does_not_mean_frequency_agreement(self):
        metrics = vector_metrics(torch.tensor([0., 3., 1.]), torch.tensor([0., 2., 1.]))
        self.assertEqual(metrics["presence_f1"], 1.)
        self.assertEqual(metrics["active_coordinate_exact_rate"], .5)
        self.assertAlmostEqual(metrics["mae"], 1 / 3)


if __name__ == "__main__":
    unittest.main()
